public class Main {
    public static void main(String[] args) {
        StudentPortal portal = new StudentPortal();
        portal.run();
    }
}
