public class NumberGuessingGameApp {
    public static void main(String[] args) {
        NumberGuessingGame game = new NumberGuessingGame();
        game.startGame();
        GameReport report = new GameReport();
        report.printReport(game);
    }
}

