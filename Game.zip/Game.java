public abstract class Game {
    protected int numberOfAttempts;

    public Game() {
        numberOfAttempts = 0;
    }

    public int getNumberOfAttempts() {
        return numberOfAttempts;
    }

    protected void incrementAttempts() {
        numberOfAttempts++;
    }

    public abstract void startGame();
}
