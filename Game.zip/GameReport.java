public class GameReport {
    public void printReport(Game game) {
        System.out.println("Game Report:");
        System.out.println("Number of Attempts: " + game.getNumberOfAttempts());
        if (game instanceof NumberGuessingGame) {
            NumberGuessingGame numberGame = (NumberGuessingGame) game;
            if (numberGame.isGameWon()) {
                System.out.println("Congratulations! You won the game.");
            } else {
                System.out.println("Better luck next time.");
            }
        }
    }
}
