import java.util.Random;
import java.util.Scanner;

public class NumberGuessingGame extends Game {
    private int targetNumber;
    private static final int MAX_TRIES = 10;
    private boolean gameWon;

    public NumberGuessingGame() {
        super();
        Random rand = new Random();
        targetNumber = rand.nextInt(100) + 1; // Number between 1 and 100
        gameWon = false;
    }

    @Override
    public void startGame() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the Number Guessing Game!");
        System.out.println("Guess the number between 1 and 100.");

        while (numberOfAttempts < MAX_TRIES && !gameWon) {
            System.out.print("Enter your guess: ");
            int guess = scanner.nextInt();
            incrementAttempts();

            if (guess < targetNumber) {
                System.out.println("Too low!");
            } else if (guess > targetNumber) {
                System.out.println("Too high!");
            } else {
                System.out.println("Congratulations! You guessed the number!");
                gameWon = true;
            }

            if (numberOfAttempts >= MAX_TRIES && !gameWon) {
                System.out.println("Sorry, you've run out of attempts. The number was " + targetNumber);
            }
        }
        scanner.close();
    }

    public boolean isGameWon() {
        return gameWon;
    }
}
